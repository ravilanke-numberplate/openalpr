import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from uploads.core.models import Document
from uploads.core.forms import DocumentForm
import requests
import base64
import json# Sample image file is available at http://plates.openalpr.com/ea7the.jpg

def home(request):
    documents = Document.objects.all()
    return render(request, 'core/home.html', { 'documents': documents })


def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        IMAGE_PATH = os.path.join(BASE_DIR, 'C:/Users/K/simple-file-upload' + uploaded_file_url)
        SECRET_KEY = 'sk_4548e345bac7d6139a0c7d40'
        with open(IMAGE_PATH, 'rb') as image_file: 
            img_base64 = base64.b64encode(image_file.read())
            url = 'https://api.openalpr.com/v3/recognize_bytes?recognize_vehicle=1&country=us&secret_key=%s' % (SECRET_KEY)
            r = requests.post(url, data = img_base64)
            m = json.loads(r.text)
            return render(request, 'core/simple_upload.html', {
                'uploaded_file_url': uploaded_file_url,
                'file_data': m['results'][0]['candidates'][0]['plate']
            })
    return render(request, 'core/simple_upload.html')


def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = DocumentForm()
    return render(request, 'core/model_form_upload.html', {
        'form': form
    })
